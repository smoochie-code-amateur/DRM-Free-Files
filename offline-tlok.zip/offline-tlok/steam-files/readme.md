### Hello! Read this!!
These Steam files are for people, who cannot have access to Steam and don't have Key for the game (I mean, this thing costs $300, bruh). 

### Installation!!
Put files into folder of the game.